﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prova26_02
{
    internal class Moto : Veiculo
    {
        public int _cilindradas;
        public bool _partidaEletrica;
        public double _peso;
        public int _capacidadeTanque;
        public override double CalcularValorAluguel(double qtdDias)
        {
            if (qtdDias > 5)
            {
                _valorAluguel = _valorAluguel - (_valorAluguel * 0.15);
            }
            return _valorAluguel;
        }
    }
}
