﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prova26_02
{
    internal class Caminhao : Veiculo
    {
        public int _qtdEixos;
        public int _capacidadeCarga;
        public string _tipoCarroceria;
        public double _comprimento;
        public double _altura;

        public override double CalcularValorAluguel(double qtdDias)
        {
            if (_capacidadeCarga > 10.000)
            {
                _valorAluguel = _valorAluguel + (_valorAluguel * 0.20);
            }
            return _valorAluguel;
        }
    }
}
