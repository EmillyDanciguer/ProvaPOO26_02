﻿using System.ComponentModel;
using System.Security.Cryptography.X509Certificates;

namespace Prova26_02
{
    public class Veiculo
    {
        public int _idVeiculo;
        public string _descricao;
        public string _marca;
        public int _anoFabricacao;
        public double _valorAluguel;

        public virtual double CalcularValorAluguel(double qtdDias)
        {
            double valorTotal = 0;
            valorTotal = _valorAluguel * qtdDias;
            return valorTotal;
        }
        
    }
}

    

