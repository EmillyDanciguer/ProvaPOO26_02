﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prova26_02
{
    internal class Aluguel 
    {
        public DateOnly _dataInicio;
        public DateOnly _dataFim;
        public int _totaDias;
        public double valorTotal;

        public double CalculoValorTotal(double valorTotal)
        {
            return valorTotal;
        }
    }
}
