﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prova26_02
{
    internal class Carro : Veiculo
    {
        public int _qtdPortas;
        public double _tamanhoBagageiro;

        public override double CalcularValorAluguel(double qtdDias)
        {
            if (qtdDias > 7)
            {
                _valorAluguel = _valorAluguel - (_valorAluguel * 0.10);
            }
            return _valorAluguel;
        }
    }
}
